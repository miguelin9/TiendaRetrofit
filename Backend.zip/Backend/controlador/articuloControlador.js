var mongoose = require('mongoose');

var Articulo = mongoose.model('Articulos');

exports.listarTodosArticulos = function(req, res) {
  Articulo.find({}, function (err, datos){
    if (err) throw err;
    res.json(datos);
  });
};
exports.crearArticulo = function(req, res) {
    var articulo  = new Articulo(req.body);
      articulo.save(function(err, data) {
            if (err)
              res.status(409).json({ mensaje : 'Código ya existe o campos vácios' });
          console.log('Articulo añadido: ' + articulo);
          res.status(201).json({ mensaje : 'Artículo creado correctamente' });
      });
};

exports.listarUnArticulos = function(req, res) {
    Articulo.find({codigo : req.params.codigo}, function(err, data) {
          if (err)
            res.send(err);
        res.json(data);
          });
};

exports.borrarUnArticulos = function(req, res) {


    Articulo.remove({codigo : req.params.codigo
        }, function(err, data) {
              if (err)
            res.send(err);
        res.json({ mensaje: 'Articulo borrado correctamente' });
          });
};


exports.actualizarUnArticulos = function(req, res) {
    Articulo.update({codigo : req.params.codigo}, req.body, { upsert: true, new: true }, function(err, data) {
          if (err)
            res.send(err);
        res.json(data);
          });
};
