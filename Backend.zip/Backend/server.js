var express = require('express'),
  tienda = express(),
  port = process.env.PORT || 3000,
  mongoose = require('mongoose'),
  Articulo = require('./modelo/articuloModelo'),
  bodyParser = require('body-parser');

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/tienda');

tienda.use(bodyParser.urlencoded({ extended: true }));
tienda.use(bodyParser.json());

var routes = require('./rutas/articuloRutas');
routes(tienda); //register the route

tienda.listen(port);

console.log('all list RESTful API server started on: ' + port);
