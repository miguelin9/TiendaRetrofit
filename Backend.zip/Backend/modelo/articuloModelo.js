var mongoose = require('mongoose');
var Schema   = mongoose.Schema;

var articuloSchema = new Schema ({

  codigo      : {type : Number, unique : true, required : true},
  foto        : String,
  nombre      : {type : String, required : true},
  categoria   : String,
  precio      : Number,
  stock       : {type : Number, required : true},
  descripcion : String
  
});

var Articulo = mongoose.model('Articulos', articuloSchema);
module.exports=Articulo;
