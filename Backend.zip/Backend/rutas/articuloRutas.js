module.exports = function(tienda) {
  var articulos = require('../controlador/articuloControlador');

  tienda.route('/articulos')
    .get(articulos.listarTodosArticulos)
    .post(articulos.crearArticulo);

  tienda.route('/articulos/:codigo')
    .get(articulos.listarUnArticulos)
    .delete(articulos.borrarUnArticulos)
    .put(articulos.actualizarUnArticulos);
}
